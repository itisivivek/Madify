import { motion } from "framer-motion";
import { Search, CalendarCheck, ThumbsUp } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: <Search className="h-6 w-6" />,
      title: "1. Search",
      description: "Browse through our selection of verified service providers"
    },
    {
      icon: <CalendarCheck className="h-6 w-6" />,
      title: "2. Book",
      description: "Choose the service you need and select a convenient time"
    },
    {
      icon: <ThumbsUp className="h-6 w-6" />,
      title: "3. Enjoy",
      description: "Relax while our professionals take care of your home"
    }
  ];
  
  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };
  
  return (
    <section className="py-16">
      <h2 className="text-2xl md:text-3xl font-serif font-semibold text-gray-900 text-center mb-6">How It Works</h2>
      <div className="w-16 h-0.5 bg-primary mx-auto mb-12"></div>
      
      <motion.div 
        className="grid md:grid-cols-3 gap-8"
        variants={container}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
      >
        {steps.map((step, index) => (
          <motion.div key={index} className="text-center" variants={item}>
            <div className="w-16 h-16 bg-indigo-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              {step.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
            <p className="text-gray-600">{step.description}</p>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
