import { Link } from "wouter";
import { Mail, Phone, MapPin, ArrowUpRight } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-dark-olive text-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-12 gap-12">
          <div className="md:col-span-4">
            <h3 className="text-2xl font-bold mb-6 tracking-tight text-white">Madify</h3>
            <p className="text-white mb-8 max-w-md">
              Finding reliable home services has never been easier. Experience the Madify difference today with our vetted professionals.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-light-cream mr-3 mt-0.5" />
                <p className="text-white">
                  West Punjabi Bagh<br />
                  New Delhi, 110026
                </p>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 text-light-cream mr-3" />
                <a href="tel:+918604747918" className="text-white hover:text-light-cream">(+91) 8604747918</a>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-light-cream mr-3" />
                <a href="mailto:info@madify.com" className="text-white hover:text-light-cream">info@madify.com</a>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="text-sm font-medium uppercase tracking-wider text-light-cream mb-6">Services</h4>
            <ul className="space-y-3">
              <li><Link href="/#services" className="text-white hover:text-light-cream inline-flex items-center">House Cleaning <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
              <li><Link href="/#services" className="text-white hover:text-light-cream inline-flex items-center">Dish Washing <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
              <li><Link href="/#services" className="text-white hover:text-light-cream inline-flex items-center">Laundry & Ironing <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
              <li><Link href="/#services" className="text-white hover:text-light-cream inline-flex items-center">Childcare <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="text-sm font-medium uppercase tracking-wider text-light-cream mb-6">Company</h4>
            <ul className="space-y-3">
              <li><Link href="/#about" className="text-white hover:text-light-cream inline-flex items-center">About Us <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
              <li><Link href="/#how-it-works" className="text-white hover:text-light-cream inline-flex items-center">How It Works <ArrowUpRight className="h-3 w-3 ml-1.5" /></Link></li>
              <li><button onClick={() => window.location.href='#'} className="text-white hover:text-light-cream inline-flex items-center">Careers <ArrowUpRight className="h-3 w-3 ml-1.5" /></button></li>
              <li><button onClick={() => window.location.href='#'} className="text-white hover:text-light-cream inline-flex items-center">Contact <ArrowUpRight className="h-3 w-3 ml-1.5" /></button></li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="text-sm font-medium uppercase tracking-wider text-light-cream mb-6">Legal</h4>
            <ul className="space-y-3">
              <li><button onClick={() => window.location.href='#'} className="text-white hover:text-light-cream inline-flex items-center">Terms of Service <ArrowUpRight className="h-3 w-3 ml-1.5" /></button></li>
              <li><button onClick={() => window.location.href='#'} className="text-white hover:text-light-cream inline-flex items-center">Privacy Policy <ArrowUpRight className="h-3 w-3 ml-1.5" /></button></li>
              <li><button onClick={() => window.location.href='#'} className="text-white hover:text-light-cream inline-flex items-center">Cookie Policy <ArrowUpRight className="h-3 w-3 ml-1.5" /></button></li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="text-sm font-medium uppercase tracking-wider text-light-cream mb-6">Follow Us</h4>
            <div className="flex space-x-4">
              <button onClick={() => window.open('#', '_blank')} className="p-2 border border-light-cream rounded-none hover:border-light-beige hover:text-light-beige text-white transition-colors">
                <span className="sr-only">Facebook</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-facebook"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
              </button>
              <button onClick={() => window.open('#', '_blank')} className="p-2 border border-light-cream rounded-none hover:border-light-beige hover:text-light-beige text-white transition-colors">
                <span className="sr-only">Twitter</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-twitter"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
              </button>
              <button onClick={() => window.open('#', '_blank')} className="p-2 border border-light-cream rounded-none hover:border-light-beige hover:text-light-beige text-white transition-colors">
                <span className="sr-only">Instagram</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-instagram"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
              </button>
              <button onClick={() => window.open('#', '_blank')} className="p-2 border border-light-cream rounded-none hover:border-light-beige hover:text-light-beige text-white transition-colors">
                <span className="sr-only">LinkedIn</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-linkedin"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-light-cream mt-16 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white text-sm">© {new Date().getFullYear()} Madify. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0 text-sm text-white">
            <button onClick={() => window.location.href='#'} className="hover:text-light-cream">Sitemap</button>
            <span>|</span>
            <button onClick={() => window.location.href='#'} className="hover:text-light-cream">Accessibility</button>
            <span>|</span>
            <button onClick={() => window.location.href='#'} className="hover:text-light-cream">Languages</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
