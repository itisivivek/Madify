import { Link, useLocation } from "wouter";
import { Home, Search, Calendar, User } from "lucide-react";

export default function MobileNavigation() {
  const [location] = useLocation();
  
  return (
    <div className="mobile-nav bg-white shadow-lg border-t border-gray-200 md:hidden">
      <div className="flex justify-around">
        <Link 
          href="/" 
          className={`flex flex-col items-center py-3 ${location === "/" ? "text-primary" : "text-gray-500"}`}
        >
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Home</span>
        </Link>
        <Link 
          href="/#services"
          className="flex flex-col items-center py-3 text-gray-500"
        >
          <Search className="h-5 w-5" />
          <span className="text-xs mt-1">Search</span>
        </Link>
        <Link 
          href="/bookings"
          className={`flex flex-col items-center py-3 ${location === "/bookings" ? "text-primary" : "text-gray-500"}`}
        >
          <Calendar className="h-5 w-5" />
          <span className="text-xs mt-1">Bookings</span>
        </Link>
        <Link 
          href="/profile"
          className={`flex flex-col items-center py-3 ${location === "/profile" ? "text-primary" : "text-gray-500"}`}
        >
          <User className="h-5 w-5" />
          <span className="text-xs mt-1">Profile</span>
        </Link>
      </div>
    </div>
  );
}
