import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function CTA() {
  const [_, navigate] = useLocation();
  
  return (
    <motion.section 
      className="bg-primary rounded-2xl p-8 md:p-12 text-white text-center mb-16"
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Simplify Your Home Maintenance?</h2>
      <p className="text-indigo-100 text-lg mb-8 max-w-2xl mx-auto">
        Join thousands of satisfied customers who have transformed their home cleaning experience with Madify.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <Button 
          size="lg"
          variant="secondary" 
          onClick={() => {
            // Scroll to top and navigate to services section
            window.scrollTo({ top: 0, behavior: 'smooth' });
            setTimeout(() => {
              const servicesSection = document.getElementById('services');
              if (servicesSection) {
                servicesSection.scrollIntoView({ behavior: 'smooth' });
              }
            }, 500);
          }}
        >
          Get Started
        </Button>
        <Button 
          size="lg"
          variant="outline" 
          className="bg-transparent border border-white text-white hover:bg-indigo-600"
          onClick={() => {
            const howItWorksSection = document.getElementById('how-it-works');
            if (howItWorksSection) {
              howItWorksSection.scrollIntoView({ behavior: 'smooth' });
            }
          }}
        >
          Learn More
        </Button>
      </div>
    </motion.section>
  );
}
