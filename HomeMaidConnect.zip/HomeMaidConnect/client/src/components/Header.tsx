import { Link } from "wouter";
import { Menu } from "lucide-react";
import { 
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="sticky top-0 z-40 bg-white">
      <div className="border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center">
              <Link href="/" className="flex items-center">
                <span className="text-gray-900 font-serif font-semibold text-2xl tracking-tight">Mad<span className="text-primary">ify</span></span>
              </Link>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <nav className="flex space-x-8">
                <Link href="/" className="text-gray-600 hover:text-primary font-medium text-sm uppercase tracking-wide">
                  Home
                </Link>
                <Link href="/#services" className="text-gray-600 hover:text-primary font-medium text-sm uppercase tracking-wide">
                  Services
                </Link>
                <Link href="/#how-it-works" className="text-gray-600 hover:text-primary font-medium text-sm uppercase tracking-wide">
                  How it Works
                </Link>
                <Link href="/#about" className="text-gray-600 hover:text-primary font-medium text-sm uppercase tracking-wide">
                  About
                </Link>
              </nav>
              
              <div className="flex items-center space-x-4">
                <Button variant="outline" className="text-primary rounded-none px-6">
                  Log in
                </Button>
                <Button className="rounded-none px-6">
                  Sign up
                </Button>
              </div>
            </div>
            
            {/* Mobile menu */}
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent>
                  <span className="text-gray-900 font-serif font-semibold text-2xl tracking-tight block mb-8">Mad<span className="text-primary">ify</span></span>
                  <div className="flex flex-col gap-6 mt-8">
                    <Link href="/" className="text-lg font-medium uppercase tracking-wide">
                      Home
                    </Link>
                    <Link href="/#services" className="text-lg font-medium uppercase tracking-wide">
                      Services
                    </Link>
                    <Link href="/#how-it-works" className="text-lg font-medium uppercase tracking-wide">
                      How it Works
                    </Link>
                    <Link href="/#about" className="text-lg font-medium uppercase tracking-wide">
                      About
                    </Link>
                    
                    <div className="flex flex-col gap-3 mt-4">
                      <Button variant="outline" className="w-full rounded-none">
                        Log in
                      </Button>
                      <Button className="w-full rounded-none">
                        Sign up
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
