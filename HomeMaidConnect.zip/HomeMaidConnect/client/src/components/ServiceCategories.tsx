import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ChevronRight, Loader2, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { type Category } from "@shared/schema";

interface ServiceCategoriesProps {
  categories: Category[];
  isLoading: boolean;
  onCategorySelect: (id: string) => void;
}

export default function ServiceCategories({ categories, isLoading, onCategorySelect }: ServiceCategoriesProps) {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  
  const handleCategoryClick = (id: number) => {
    setSelectedCategory(id);
    onCategorySelect(id.toString());
    
    // Scroll down to providers section
    setTimeout(() => {
      const providersSection = document.getElementById('providers');
      if (providersSection) {
        providersSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };
  
  // Animation variants for staggered children
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };
  
  if (isLoading) {
    return (
      <section id="services" className="py-20 bg-olive">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-semibold text-gray-900 tracking-tight">Our Services</h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mt-4"></div>
          </div>
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
          </div>
        </div>
      </section>
    );
  }
  
  return (
    <section id="services" className="py-24 bg-olive">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-semibold text-gray-900 tracking-tight mb-2">Our Services</h2>
          <div className="w-16 h-0.5 bg-primary mt-4"></div>
          <p className="mt-4 text-lg max-w-2xl section-tagline">
            Browse our wide range of professional home services tailored to your needs
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 md:gap-8"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {categories.map((category) => (
            <motion.div key={category.id} variants={item}>
              <Card 
                className={`border border-gray-100 transition-all duration-300 hover:shadow-md cursor-pointer group overflow-hidden rounded-none ${
                  selectedCategory === category.id 
                    ? 'border-gray-300' 
                    : 'border-gray-100'
                }`}
                onClick={() => handleCategoryClick(category.id)}
              >
                <CardContent className="p-6 relative bg-white h-full">
                  <div className="mb-4">
                    <span className={`material-icons ${category.iconColor} text-2xl`}>{category.icon}</span>
                  </div>
                  
                  <h3 className="text-lg service-title text-gray-900 mb-2">{category.name}</h3>
                  <p className="text-sm text-gray-500 font-light leading-relaxed">{category.description}</p>
                  
                  <div className="mt-4 group-hover:text-primary transition-colors duration-300">
                    <div className="inline-flex items-center text-sm">
                      View <ArrowRight className="ml-1 h-3 w-3" />
                    </div>
                  </div>
                  
                  {selectedCategory === category.id && (
                    <div className="absolute bottom-0 left-0 w-full h-0.5 bg-primary"></div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
