import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FilterIcon, Search } from "lucide-react";
import { type Category } from "@shared/schema";

interface ServiceFiltersProps {
  categoryFilter: string;
  setCategoryFilter: (value: string) => void;
  priceFilter: number;
  setPriceFilter: (value: number) => void;
  ratingFilter: string;
  setRatingFilter: (value: string) => void;
  dateFilter: string;
  setDateFilter: (value: string) => void;
  onApplyFilters: () => void;
  onResetFilters: () => void;
  categories: Category[];
}

export default function ServiceFilters({
  categoryFilter,
  setCategoryFilter,
  priceFilter,
  setPriceFilter,
  ratingFilter,
  setRatingFilter,
  dateFilter,
  setDateFilter,
  onApplyFilters,
  onResetFilters,
  categories,
}: ServiceFiltersProps) {
  const [localPrice, setLocalPrice] = useState(priceFilter);
  
  // Update local price when prop changes
  useEffect(() => {
    setLocalPrice(priceFilter);
  }, [priceFilter]);
  
  // Handle slider change
  const handlePriceChange = (value: number[]) => {
    setLocalPrice(value[0]);
  };
  
  // Handle apply button
  const handleApply = () => {
    setPriceFilter(localPrice);
    onApplyFilters();
    
    // Scroll to providers section
    const providersSection = document.getElementById('providers');
    if (providersSection) {
      providersSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="py-12 bg-white"
      id="filters"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-8">
          <FilterIcon className="h-6 w-6 text-primary mr-3" />
          <h2 className="text-2xl font-serif font-semibold text-gray-900 tracking-tight">Find Your Perfect Service</h2>
        </div>
        
        <Card className="border-0 shadow-md rounded-none overflow-hidden">
          <CardContent className="p-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* Category Filter */}
              <div>
                <Label htmlFor="category" className="block text-sm font-medium uppercase tracking-wider text-gray-500 mb-3 form-label">
                  Service Category
                </Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger id="category" className="rounded-none border-gray-200 h-12">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {/* Budget Filter */}
              <div>
                <Label htmlFor="budget" className="block text-sm font-medium uppercase tracking-wider text-gray-500 mb-3 form-label">
                  Budget: <span className="text-primary font-semibold price">₹{localPrice}/hr</span>
                </Label>
                <Slider
                  id="budget"
                  min={100}
                  max={500}
                  step={50}
                  value={[localPrice]}
                  onValueChange={handlePriceChange}
                  className="py-4"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>₹100</span>
                  <span>₹500</span>
                </div>
              </div>
              
              {/* Rating Filter */}
              <div>
                <Label htmlFor="rating" className="block text-sm font-medium uppercase tracking-wider text-gray-500 mb-3 form-label">
                  Min Rating
                </Label>
                <Select value={ratingFilter} onValueChange={setRatingFilter}>
                  <SelectTrigger id="rating" className="rounded-none border-gray-200 h-12">
                    <SelectValue placeholder="Any Rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Any Rating</SelectItem>
                    <SelectItem value="3">3+ Stars</SelectItem>
                    <SelectItem value="4">4+ Stars</SelectItem>
                    <SelectItem value="5">5 Stars Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Availability Filter */}
              <div>
                <Label htmlFor="date" className="block text-sm font-medium uppercase tracking-wider text-gray-500 mb-3 form-label">
                  Available Date
                </Label>
                <input 
                  type="date" 
                  id="date" 
                  className="w-full rounded-none border border-gray-200 p-3 h-12 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
            </div>
            
            <div className="mt-8 flex justify-end">
              <Button
                variant="outline"
                onClick={onResetFilters}
                className="mr-4 rounded-none border-gray-300 h-12 px-6"
              >
                Reset
              </Button>
              <Button 
                onClick={handleApply}
                className="rounded-none h-12 px-8 flex items-center"
              >
                <Search className="h-4 w-4 mr-2" />
                Search Services
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </motion.section>
  );
}
