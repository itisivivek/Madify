import { useEffect, useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, MapPin, Star, ArrowRight, ArrowUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface ServiceProviderWithCategories {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
  rating: number;
  pricePerHour: number;
  distance: number;
  location: string;
  categories: {
    id: number;
    name: string;
    description: string;
    icon: string;
    iconBg: string;
    iconColor: string;
  }[];
}

interface ServiceProvidersProps {
  providers: ServiceProviderWithCategories[];
  isLoading: boolean;
  sortBy: string;
  setSortBy: (value: string) => void;
}

export default function ServiceProviders({ 
  providers, 
  isLoading,
  sortBy,
  setSortBy
}: ServiceProvidersProps) {
  const [displayedProviders, setDisplayedProviders] = useState<ServiceProviderWithCategories[]>([]);
  const [visibleCount, setVisibleCount] = useState(3);
  
  // Sort providers based on selected option
  useEffect(() => {
    if (!providers) return;
    
    let sortedProviders = [...providers];
    
    switch (sortBy) {
      case "rating":
        sortedProviders.sort((a, b) => b.rating - a.rating);
        break;
      case "price":
        sortedProviders.sort((a, b) => a.pricePerHour - b.pricePerHour);
        break;
      case "distance":
        sortedProviders.sort((a, b) => a.distance - b.distance);
        break;
      default:
        // Default to rating
        sortedProviders.sort((a, b) => b.rating - a.rating);
    }
    
    setDisplayedProviders(sortedProviders);
  }, [providers, sortBy]);
  
  const loadMore = () => {
    setVisibleCount(prev => Math.min(prev + 3, displayedProviders.length));
  };
  
  if (isLoading) {
    return (
      <section id="providers" className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">Top Rated Service Providers</h2>
            <div className="w-16 h-0.5 bg-primary mt-4"></div>
            <p className="mt-4 text-lg text-gray-500 max-w-2xl font-light leading-relaxed">
              Discover our highest rated professional service providers in your area
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border border-gray-100 rounded-none overflow-hidden">
                <Skeleton className="h-52 w-full" />
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <Skeleton className="h-5 w-32 mb-2" />
                      <Skeleton className="h-4 w-20 mb-3" />
                    </div>
                    <Skeleton className="h-5 w-14" />
                  </div>
                  <div className="mt-3">
                    <div className="flex gap-1 mb-3">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-full mt-1" />
                    <Skeleton className="h-3 w-3/4 mt-1" />
                  </div>
                  <div className="mt-6 flex justify-between">
                    <Skeleton className="h-8 w-20" />
                    <Skeleton className="h-8 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }
  
  if (!displayedProviders.length) {
    return (
      <section id="providers" className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-16">
            <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">Available Service Providers</h2>
            <div className="w-16 h-0.5 bg-primary mt-4"></div>
            <p className="mt-4 text-lg text-gray-500 max-w-2xl font-light leading-relaxed">
              Browse service providers based on your filter preferences
            </p>
          </div>
          
          <Card className="p-12 text-center border border-gray-100 rounded-none">
            <h3 className="text-xl font-medium text-gray-800 mb-4">No service providers found</h3>
            <p className="text-gray-500 mb-6 max-w-md mx-auto font-light">Try adjusting your filters to see more results or browse our complete list of service providers.</p>
            <Button onClick={() => window.location.reload()} className="rounded-none px-6 py-2 text-sm">Reset Filters</Button>
          </Card>
        </div>
      </section>
    );
  }
  
  return (
    <section id="providers" className="py-24 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">Top Rated Service Providers</h2>
          <div className="w-16 h-0.5 bg-primary mt-4"></div>
          <p className="mt-4 text-lg max-w-2xl section-tagline">
            Discover our highest rated professional service providers in your area
          </p>
        </div>
        
        <div className="flex justify-end items-center mb-12">
          <div className="flex items-center">
            <span className="text-sm text-gray-500 mr-4">Sort by:</span>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[160px] rounded-none border-gray-200 h-10">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="price">Lowest Price</SelectItem>
                <SelectItem value="distance">Closest</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6 md:gap-8">
          <AnimatePresence>
            {displayedProviders.slice(0, visibleCount).map((provider, index) => (
              <motion.div
                key={provider.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ 
                  duration: 0.3,
                  delay: index * 0.1 
                }}
              >
                <Card className="border border-gray-100 rounded-none overflow-hidden group hover:border-gray-200 transition-all duration-300">
                  <div className="relative h-52">
                    <img 
                      src={provider.imageUrl} 
                      alt={provider.name} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                      <div className="flex justify-between items-end">
                        <h3 className="text-base service-title-light">{provider.name}</h3>
                        <div className="bg-white/90 px-2 py-1 text-xs font-medium text-gray-700 flex items-center rating">
                          {provider.rating} <Star className="h-3 w-3 ml-0.5 fill-amber-400 stroke-amber-400" />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-400" />
                        <span className="text-xs text-gray-500 ml-1">{provider.distance} km away</span>
                      </div>
                      <span className="text-base font-medium text-gray-900 price">
                        ₹{provider.pricePerHour}<span className="text-xs text-gray-500 font-normal">/hr</span>
                      </span>
                    </div>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {provider.categories?.slice(0, 3).map(category => (
                        <Badge
                          key={category.id}
                          variant="outline"
                          className="text-xs service-title bg-gray-50 border-gray-200 py-0.5 px-2 rounded-none"
                        >
                          {category.name}
                        </Badge>
                      ))}
                    </div>
                    
                    <p className="text-sm text-gray-500 line-clamp-2 mb-4 font-light">
                      {provider.description}
                    </p>
                    
                    <div className="flex justify-between items-center">
                      <Link href={`/providers/${provider.id}`} className="text-gray-600 hover:text-gray-900 text-xs font-medium inline-flex items-center transition-colors">
                        Details <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                      <Link href={`/booking/${provider.id}`}>
                        <span className="inline-block">
                          <Button 
                            className="rounded-none text-sm px-4 py-1.5 h-auto"
                          >
                            Book Now
                          </Button>
                        </span>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        {visibleCount < displayedProviders.length && (
          <div className="mt-10 text-center">
            <Button 
              variant="outline" 
              onClick={loadMore}
              className="rounded-none px-6 py-2 border-gray-300 hover:bg-gray-100 hover:text-gray-900 inline-flex items-center gap-1 text-sm"
            >
              Load More
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
