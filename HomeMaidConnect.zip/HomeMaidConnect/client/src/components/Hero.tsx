import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MapPin, ChevronDown } from "lucide-react";
import { motion } from "framer-motion";

interface HeroProps {
  location: string;
  setLocation: (location: string) => void;
}

export default function Hero({ location, setLocation }: HeroProps) {
  const [isInputFocused, setIsInputFocused] = useState(false);
  
  const handleFindServices = () => {
    // Scroll to services section
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      servicesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  const scrollToNextSection = () => {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      servicesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <div className="relative hero-container">
      {/* Clean minimalist background */}
      <div className="absolute inset-0 w-full h-full bg-beige z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-cream to-beige opacity-80"></div>
      </div>
      
      <section className="relative z-10 pt-24 pb-32 md:pt-32 md:pb-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-12 gap-8 items-center">
            <motion.div
              className="md:col-span-8 lg:col-span-6 md:pr-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-semibold text-gray-900 leading-tight tracking-tight">
                Quality Home Services, <br /><span className="text-primary">Just a Tap Away</span>
              </h1>
              <p className="mt-5 text-lg md:text-xl max-w-lg section-tagline">
                Find reliable home help that fits your budget. Professional maids, cleaners, and more.
              </p>
              
              <div className="mt-8 flex flex-col sm:flex-row gap-2 items-start sm:items-center">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Enter your location"
                    className={`pl-10 pr-3 py-5 h-auto rounded-none border border-gray-200 text-sm ${isInputFocused ? 'ring-0 border-gray-400' : ''}`}
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    onFocus={() => setIsInputFocused(true)}
                    onBlur={() => setIsInputFocused(false)}
                  />
                </div>
                <Button 
                  className="whitespace-nowrap rounded-none px-6 py-5 h-auto text-sm font-medium" 
                  onClick={handleFindServices}
                >
                  Find Services
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Scroll down indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <motion.button 
            onClick={scrollToNextSection}
            className="text-gray-400 flex flex-col items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: 1 }}
          >
            <span className="text-xs uppercase tracking-wider mb-1 font-light">Explore</span>
            <ChevronDown className="h-4 w-4" />
          </motion.button>
        </div>
      </section>
    </div>
  );
}
