import { useState } from "react";
import Hero from "@/components/Hero";
import ServiceCategories from "@/components/ServiceCategories";
import ServiceFilters from "@/components/ServiceFilters";
import ServiceProviders from "@/components/ServiceProviders";
import HowItWorks from "@/components/HowItWorks";
import Testimonials from "@/components/Testimonials";
import CTA from "@/components/CTA";
import { useQuery } from "@tanstack/react-query";
import { type Category } from "@shared/schema";

// Define necessary types
interface ServiceProviderWithCategories {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
  rating: number;
  pricePerHour: number;
  distance: number;
  location: string;
  categories: {
    id: number;
    name: string;
    description: string;
    icon: string;
    iconBg: string;
    iconColor: string;
  }[];
}

export default function Home() {
  // Filter state
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [priceFilter, setPriceFilter] = useState<number>(300);
  const [ratingFilter, setRatingFilter] = useState<string>("4");
  const [dateFilter, setDateFilter] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("rating");
  const [location, setLocation] = useState<string>("");

  // Filtered providers query
  const { data: providers, isLoading: isLoadingProviders } = useQuery<ServiceProviderWithCategories[]>({
    queryKey: ['/api/providers', categoryFilter, priceFilter, ratingFilter],
    refetchOnWindowFocus: false,
  });
  
  // Categories query
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    refetchOnWindowFocus: false,
  });

  // Handler for filter changes
  const handleApplyFilters = () => {
    // Filters are applied via query params, so the query will auto-refetch
  };

  const handleResetFilters = () => {
    setCategoryFilter("");
    setPriceFilter(300);
    setRatingFilter("4");
    setDateFilter("");
  };

  return (
    <div className="bg-white text-gray-900">
      <Hero location={location} setLocation={setLocation} />
      
      <ServiceCategories 
        categories={categories || []} 
        isLoading={isLoadingCategories}
        onCategorySelect={(id) => setCategoryFilter(id)}
      />
      
      <ServiceFilters 
        categoryFilter={categoryFilter}
        setCategoryFilter={setCategoryFilter}
        priceFilter={priceFilter}
        setPriceFilter={setPriceFilter}
        ratingFilter={ratingFilter}
        setRatingFilter={setRatingFilter}
        dateFilter={dateFilter}
        setDateFilter={setDateFilter}
        onApplyFilters={handleApplyFilters}
        onResetFilters={handleResetFilters}
        categories={categories || []}
      />
      
      <ServiceProviders 
        providers={providers || []} 
        isLoading={isLoadingProviders}
        sortBy={sortBy}
        setSortBy={setSortBy}
      />
      
      <section id="how-it-works" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <HowItWorks />
        </div>
      </section>
      
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Testimonials />
        </div>
      </section>
      
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <CTA />
        </div>
      </section>
    </div>
  );
}
