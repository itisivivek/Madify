import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { StarIcon, MapPin, Check, ArrowLeft } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";

export default function ServiceDetail() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  
  const { data: provider, isLoading } = useQuery({
    queryKey: [`/api/providers/${id}`],
    refetchOnWindowFocus: false,
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button
          variant="ghost"
          className="mb-6 flex items-center gap-2"
          onClick={() => navigate('/')}
        >
          <ArrowLeft size={16} /> Back to services
        </Button>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Skeleton className="h-96 w-full rounded-2xl" />
            <Skeleton className="h-10 w-3/4 mt-6" />
            <div className="mt-4 space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
          
          <div>
            <Skeleton className="h-72 w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-900">Service provider not found</h2>
          <p className="mt-2 text-gray-600">The service provider you're looking for doesn't exist or has been removed.</p>
          <Button
            className="mt-6"
            onClick={() => navigate('/')}
          >
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Button
        variant="ghost"
        className="mb-6 flex items-center gap-2"
        onClick={() => navigate('/')}
      >
        <ArrowLeft size={16} /> Back to services
      </Button>
      
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="relative h-96 rounded-2xl overflow-hidden">
            <img
              src={provider.imageUrl}
              alt={provider.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1.5 text-sm font-medium text-primary shadow-sm flex items-center gap-1">
              <StarIcon className="h-4 w-4 fill-amber-400 stroke-amber-400" />
              {provider.rating}
            </div>
          </div>
          
          <h1 className="text-3xl service-title text-gray-900 mt-6">{provider.name}</h1>
          
          <div className="flex items-center gap-4 mt-2">
            <span className="flex items-center text-gray-500">
              <MapPin className="h-4 w-4 text-amber-500 mr-1" />
              {provider.distance} km away
            </span>
            <span className="text-xl font-bold text-primary">
              ₹{provider.pricePerHour}<span className="text-sm text-gray-500 font-normal">/hr</span>
            </span>
          </div>
          
          <div className="mt-4 flex flex-wrap gap-2">
            {provider.categories?.map((category) => (
              <Badge
                key={category.id}
                variant="secondary"
                className="text-xs service-title px-2.5 py-0.5"
              >
                {category.name}
              </Badge>
            ))}
          </div>
          
          <Separator className="my-6" />
          
          <div>
            <h2 className="text-xl font-semibold mb-4">About</h2>
            <p className="text-gray-700">{provider.description}</p>
          </div>
          
          <div className="mt-8">
            <h2 className="text-xl font-semibold mb-4">Services Offered</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {provider.categories?.map((category) => (
                <li key={category.id} className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <div>
                    <h3 className="service-title">{category.name}</h3>
                    <p className="text-sm text-gray-500">{category.description}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div>
          <Card className="sticky top-24">
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-4">Book This Service</h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate(`/booking/${provider.id}`)}
                  >
                    Contact
                  </Button>
                  <Button
                    className="w-full"
                    onClick={() => navigate(`/booking/${provider.id}`)}
                  >
                    Book Now
                  </Button>
                </div>
                
                <div className="text-sm text-gray-500 mt-2">
                  <p>• Flexible scheduling options</p>
                  <p>• 100% satisfaction guarantee</p>
                  <p>• Free cancellation with 24h notice</p>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="font-medium mb-2">Location</h4>
                  <p className="text-sm text-gray-700">{provider.location} area</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Service availability</h4>
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div className="bg-gray-100 p-2 rounded-md text-center">Mon</div>
                    <div className="bg-gray-100 p-2 rounded-md text-center">Tue</div>
                    <div className="bg-gray-100 p-2 rounded-md text-center">Wed</div>
                    <div className="bg-gray-100 p-2 rounded-md text-center">Thu</div>
                    <div className="bg-gray-100 p-2 rounded-md text-center">Fri</div>
                    <div className="bg-gray-100 p-2 rounded-md text-center opacity-50">Sat</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
