import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // API routes
  
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  // Get service providers
  app.get("/api/providers", async (req, res) => {
    try {
      const { category, minPrice, maxPrice, minRating } = req.query;
      let providers;
      
      // Apply filters if provided
      if (category && !isNaN(Number(category))) {
        providers = await storage.getServiceProvidersByCategory(Number(category));
      } else {
        providers = await storage.getAllServiceProviders();
      }
      
      // Apply price filter if both min and max are provided
      if (minPrice && maxPrice && !isNaN(Number(minPrice)) && !isNaN(Number(maxPrice))) {
        providers = providers.filter(
          p => p.pricePerHour >= Number(minPrice) && p.pricePerHour <= Number(maxPrice)
        );
      }
      
      // Apply rating filter
      if (minRating && !isNaN(Number(minRating))) {
        providers = providers.filter(p => p.rating >= Number(minRating));
      }
      
      // For each provider, fetch its categories
      const providersWithCategories = await Promise.all(
        providers.map(async (provider) => {
          const categoryIds = await storage.getCategoryIdsByProvider(provider.id);
          const categories = await Promise.all(
            categoryIds.map(id => storage.getCategoryById(id))
          );
          
          return {
            ...provider,
            categories: categories.filter(Boolean) // Filter out undefined values
          };
        })
      );
      
      res.json(providersWithCategories);
    } catch (error) {
      console.error("Error fetching providers:", error);
      res.status(500).json({ message: "Failed to fetch service providers" });
    }
  });
  
  // Get a single service provider by ID
  app.get("/api/providers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid provider ID" });
      }
      
      const provider = await storage.getServiceProviderById(id);
      
      if (!provider) {
        return res.status(404).json({ message: "Service provider not found" });
      }
      
      const categoryIds = await storage.getCategoryIdsByProvider(provider.id);
      const categories = await Promise.all(
        categoryIds.map(id => storage.getCategoryById(id))
      );
      
      res.json({
        ...provider,
        categories: categories.filter(Boolean)
      });
    } catch (error) {
      console.error("Error fetching provider:", error);
      res.status(500).json({ message: "Failed to fetch service provider details" });
    }
  });
  
  // Create a booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });
  
  // Get testimonials
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  return httpServer;
}
