import { 
  users, type User, type InsertUser,
  categories, type Category, type InsertCategory,
  serviceProviders, type ServiceProvider, type InsertServiceProvider,
  serviceCategories, type ServiceCategory, type InsertServiceCategory,
  bookings, type Booking, type InsertBooking,
  testimonials, type Testimonial, type InsertTestimonial
} from "@shared/schema";

// Modify the interface with CRUD methods for our application
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getAllCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Service Provider methods
  getAllServiceProviders(): Promise<ServiceProvider[]>;
  getServiceProviderById(id: number): Promise<ServiceProvider | undefined>;
  createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider>;
  getServiceProvidersByCategory(categoryId: number): Promise<ServiceProvider[]>;
  getServiceProvidersByPriceRange(min: number, max: number): Promise<ServiceProvider[]>;
  getServiceProvidersByRating(minRating: number): Promise<ServiceProvider[]>;
  
  // Service Category mappings
  createServiceCategory(serviceCategory: InsertServiceCategory): Promise<ServiceCategory>;
  getServiceCategoriesByProvider(providerId: number): Promise<ServiceCategory[]>;
  getCategoryIdsByProvider(providerId: number): Promise<number[]>;
  
  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingById(id: number): Promise<Booking | undefined>;
  
  // Testimonial methods
  getAllTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private serviceProviders: Map<number, ServiceProvider>;
  private serviceCategories: Map<number, ServiceCategory>;
  private bookings: Map<number, Booking>;
  private testimonials: Map<number, Testimonial>;
  
  private userCurrentId: number;
  private categoryCurrentId: number;
  private providerCurrentId: number;
  private serviceCategoryCurrentId: number;
  private bookingCurrentId: number;
  private testimonialCurrentId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.serviceProviders = new Map();
    this.serviceCategories = new Map();
    this.bookings = new Map();
    this.testimonials = new Map();
    
    this.userCurrentId = 1;
    this.categoryCurrentId = 1;
    this.providerCurrentId = 1;
    this.serviceCategoryCurrentId = 1;
    this.bookingCurrentId = 1;
    this.testimonialCurrentId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryCurrentId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  // Service Provider methods
  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values());
  }
  
  async getServiceProviderById(id: number): Promise<ServiceProvider | undefined> {
    return this.serviceProviders.get(id);
  }
  
  async createServiceProvider(insertProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const id = this.providerCurrentId++;
    const provider: ServiceProvider = { ...insertProvider, id };
    this.serviceProviders.set(id, provider);
    return provider;
  }
  
  async getServiceProvidersByCategory(categoryId: number): Promise<ServiceProvider[]> {
    const providerIds = new Set<number>();
    
    Array.from(this.serviceCategories.values())
      .filter(sc => sc.categoryId === categoryId)
      .forEach(sc => providerIds.add(sc.providerId));
    
    return Array.from(this.serviceProviders.values())
      .filter(provider => providerIds.has(provider.id));
  }
  
  async getServiceProvidersByPriceRange(min: number, max: number): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values())
      .filter(provider => provider.pricePerHour >= min && provider.pricePerHour <= max);
  }
  
  async getServiceProvidersByRating(minRating: number): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values())
      .filter(provider => provider.rating >= minRating);
  }
  
  // Service Category mappings
  async createServiceCategory(insertServiceCategory: InsertServiceCategory): Promise<ServiceCategory> {
    const id = this.serviceCategoryCurrentId++;
    const serviceCategory: ServiceCategory = { ...insertServiceCategory, id };
    this.serviceCategories.set(id, serviceCategory);
    return serviceCategory;
  }
  
  async getServiceCategoriesByProvider(providerId: number): Promise<ServiceCategory[]> {
    return Array.from(this.serviceCategories.values())
      .filter(sc => sc.providerId === providerId);
  }
  
  async getCategoryIdsByProvider(providerId: number): Promise<number[]> {
    return Array.from(this.serviceCategories.values())
      .filter(sc => sc.providerId === providerId)
      .map(sc => sc.categoryId);
  }
  
  // Booking methods
  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.bookingCurrentId++;
    const booking: Booking = { ...insertBooking, id, status: "pending", message: insertBooking.message || null };
    this.bookings.set(id, booking);
    return booking;
  }
  
  async getBookingById(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }
  
  // Testimonial methods
  async getAllTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }
  
  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialCurrentId++;
    const testimonial: Testimonial = { ...insertTestimonial, id };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }
  
  // Initialize with sample data
  private initializeSampleData(): void {
    // Sample Categories
    const categories: InsertCategory[] = [
      { 
        name: "Full Home Cleaning", 
        description: "Complete home deep cleaning services", 
        icon: "cleaning_services", 
        iconBg: "bg-indigo-50", 
        iconColor: "text-primary" 
      },
      { 
        name: "Cook & Kitchen Help", 
        description: "Cooking and kitchen assistance", 
        icon: "restaurant", 
        iconBg: "bg-cyan-50", 
        iconColor: "text-secondary" 
      },
      { 
        name: "Laundry & Pressing", 
        description: "Clothes washing and pressing", 
        icon: "iron", 
        iconBg: "bg-emerald-50", 
        iconColor: "text-emerald-500" 
      },
      { 
        name: "Childcare & Ayah", 
        description: "Child caretaking and nanny services", 
        icon: "baby_changing_station", 
        iconBg: "bg-amber-50", 
        iconColor: "text-amber-500" 
      },
      { 
        name: "Elder Care", 
        description: "Assistance for elderly family members", 
        icon: "elderly", 
        iconBg: "bg-rose-50", 
        iconColor: "text-rose-500" 
      },
      { 
        name: "Driver Services", 
        description: "Professional drivers for your vehicle", 
        icon: "drive_eta", 
        iconBg: "bg-sky-50", 
        iconColor: "text-sky-500" 
      }
    ];
    
    categories.forEach(category => {
      const id = this.categoryCurrentId++;
      this.categories.set(id, { ...category, id });
    });
    
    // Sample Service Providers
    const providers: InsertServiceProvider[] = [
      {
        name: "Swachh Home Services",
        description: "10+ years of experience providing thorough cleaning services with trained staff.",
        imageUrl: "https://images.unsplash.com/photo-1591272170639-45e7ed99b9a6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.9,
        pricePerHour: 350,
        distance: 2.5,
        location: "Punjabi Bagh"
      },
      {
        name: "Annapurna Kitchen Help",
        description: "Specialized in cooking delicious meals and kitchen management for busy households.",
        imageUrl: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.7,
        pricePerHour: 280,
        distance: 1.2,
        location: "Janakpuri"
      },
      {
        name: "Presswala Services",
        description: "Expert in handling delicate fabrics and providing pristine laundry and pressing services.",
        imageUrl: "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.8,
        pricePerHour: 200,
        distance: 3.7,
        location: "Rajouri Garden"
      },
      {
        name: "GharSaaf Cleaning",
        description: "Comprehensive home services with special focus on deep cleaning and sanitization.",
        imageUrl: "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.6,
        pricePerHour: 320,
        distance: 4.1,
        location: "Pitampura"
      },
      {
        name: "Aditya Driver Services",
        description: "Professional drivers with excellent track record and knowledge of local routes.",
        imageUrl: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.5,
        pricePerHour: 250,
        distance: 1.8,
        location: "Karol Bagh"
      },
      {
        name: "Mamta Childcare",
        description: "Professional ayah services with trained and certified staff to keep your children safe and happy.",
        imageUrl: "https://images.unsplash.com/photo-1595974482613-c80582a16f27?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.9,
        pricePerHour: 300,
        distance: 3.2,
        location: "Connaught Place"
      },
      {
        name: "Sahara Elder Care",
        description: "Compassionate and attentive elder care assistants for your family members.",
        imageUrl: "https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        rating: 4.8,
        pricePerHour: 400,
        distance: 2.3,
        location: "Laxmi Nagar"
      }
    ];
    
    providers.forEach(provider => {
      const id = this.providerCurrentId++;
      this.serviceProviders.set(id, { ...provider, id });
    });
    
    // Sample Service Categories mappings
    const mappings = [
      { providerId: 1, categoryId: 1 }, // Swachh Home Services - Full Home Cleaning
      { providerId: 2, categoryId: 2 }, // Annapurna Kitchen Help - Cook & Kitchen Help
      { providerId: 3, categoryId: 3 }, // Presswala Services - Laundry & Pressing
      { providerId: 4, categoryId: 1 }, // GharSaaf Cleaning - Full Home Cleaning
      { providerId: 5, categoryId: 6 }, // Aditya Driver Services - Driver Services
      { providerId: 6, categoryId: 4 }, // Mamta Childcare - Childcare & Ayah
      { providerId: 7, categoryId: 5 }, // Sahara Elder Care - Elder Care
    ];
    
    mappings.forEach(mapping => {
      const id = this.serviceCategoryCurrentId++;
      this.serviceCategories.set(id, { ...mapping, id });
    });
    
    // Sample Testimonials
    const testimonials: InsertTestimonial[] = [
      {
        name: "Priya Sharma",
        imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80",
        rating: 5.0,
        comment: "I've been using Madify for over 6 months and I couldn't be happier with the service. The cleaners are always punctual, thorough, and respect our household customs."
      },
      {
        name: "Amit Patel",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80",
        rating: 4.5,
        comment: "Finding a reliable cook was a challenge until I discovered Madify. Their budget filter made it easy to find someone within my price range of ₹250-300 per hour."
      },
      {
        name: "Neha Reddy",
        imageUrl: "https://images.unsplash.com/photo-1569913486515-b74bf7751574?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80",
        rating: 4.8,
        comment: "The elder care service from Madify has been a blessing for my family. My parents are well taken care of when I'm at work, and the caretakers are trained in handling medical emergencies."
      },
      {
        name: "Rajesh Verma",
        imageUrl: "https://images.unsplash.com/photo-1566753323558-f4e0952af115?ixlib=rb-1.2.1&auto=format&fit=crop&w=120&q=80",
        rating: 5.0,
        comment: "As a busy professional in Delhi, finding a reliable driver was essential. Madify connected me with a driver who knows all the shortcuts around the city traffic, especially around West Punjabi Bagh area."
      }
    ];
    
    testimonials.forEach(testimonial => {
      const id = this.testimonialCurrentId++;
      this.testimonials.set(id, { ...testimonial, id });
    });
  }
}

export const storage = new MemStorage();
